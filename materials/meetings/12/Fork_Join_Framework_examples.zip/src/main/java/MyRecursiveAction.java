// http://homes.cs.washington.edu/~djg/teachingMaterials/spac/grossmanSPAC_forkJoinFramework.html
// https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/RecursiveAction.html

import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.TimeUnit;


class IncrementTask extends RecursiveAction {
    final int[] array;
    final int lo, hi;
    static final int THRESHOLD = 10;

    IncrementTask(int[] array, int lo, int hi) {
        this.array = array;
        this.lo = lo;
        this.hi = hi;
    }

    protected void compute() {
        if (hi - lo < THRESHOLD) {
            for (int i = lo; i < hi; ++i)
                array[i]++;
        }
        else {
            int mid = lo + (hi - lo) / 2;
            invokeAll(new IncrementTask(array, lo, mid),
                    new IncrementTask(array, mid, hi));
        }
    }
}


public class MyRecursiveAction {

    private static Random generator = new Random();
    private static ForkJoinPool forkJoinPool;

    public static void main(String[] args) {
        //forkJoinPool = new ForkJoinPool(2);
        forkJoinPool = ForkJoinPool.commonPool();

        System.out.println(" * Wykonywanie na " + forkJoinPool.getParallelism() + " watkach.");

        wykonaj();
        wykonaj();
        wykonaj();
    }

    public static void wykonaj() {

        System.out.println("*************************");

        long t0, t1;
        int[] ex = nowaTablica(5);

        System.out.print("Tablica: ");
        for (int i = 0; i < ex.length; i++) {
            System.out.print(" " + ex[i]);
        }
        System.out.println();

        RecursiveAction task = new IncrementTask(ex, 0, ex.length);

        t0 = System.nanoTime();

        forkJoinPool.invoke(task);
        task.join();

        t1 = System.nanoTime();

        System.out.println(" * Wykonano w czasie " + TimeUnit.NANOSECONDS.toMillis(t1 - t0));

        System.out.print("Tablica: ");
        for (int i = 0; i < ex.length; i++) {
            System.out.print(" " + ex[i]);
        }
        System.out.println();

    }

    private static int[] nowaTablica(int n) {
        int[] tab = new int[n];

        for (int i = 0; i < n; i++) {
            tab[i] = generator.nextInt() % 5;
        }

        return tab;
    }
}
