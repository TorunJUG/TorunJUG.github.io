package org.jug.torun.jtwig;

public class AppTests {
}
