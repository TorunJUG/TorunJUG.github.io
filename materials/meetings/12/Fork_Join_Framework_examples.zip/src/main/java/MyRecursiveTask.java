// http://homes.cs.washington.edu/~djg/teachingMaterials/spac/grossmanSPAC_forkJoinFramework.html
// https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/RecursiveAction.html

import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.TimeUnit;


class Sum extends RecursiveTask<Long> {
    static final int THRESHOLD = 1_000;

    int low;
    int high;
    int[] array;

    Sum(int[] arr, int lo, int hi) {
        array = arr;
        low   = lo;
        high  = hi;
    }

    @Override
    protected Long compute() {
        //System.out.println("    + Wywolanie Compute()");

        if(high - low <= THRESHOLD) {
            long sum = 0;

            for(int i=low; i < high; ++i)
                sum += array[i];

            return sum;
        } else {
            int mid = low + (high - low) / 2;
            Sum left  = new Sum(array, low, mid);
            Sum right = new Sum(array, mid, high);

            left.fork();
            long rightAns = right.compute();
            long leftAns  = left.join();

            return leftAns + rightAns;
        }
    }

}


public class MyRecursiveTask {

    private static Random generator = new Random();
    private static ForkJoinPool forkJoinPool;

    public static void main(String[] args) {
        //forkJoinPool = new ForkJoinPool(2);
        forkJoinPool = ForkJoinPool.commonPool();

        System.out.println(" * Wykonywanie na " + forkJoinPool.getParallelism() + " watkach.");

        wykonaj();
        wykonaj();
        wykonaj();
    }

    public static void wykonaj() {
        long t0, t1, sum;
        int[] ex = nowaTablica(10_000_000);

        // java.util.Arrays.parallelSort(ex);

        RecursiveTask<Long> task = new Sum(ex, 0, ex.length);

        t0 = System.nanoTime();

        forkJoinPool.invoke(task);
        sum = task.join();

        t1 = System.nanoTime();

        System.out.println(" * Wykonano w czasie " + TimeUnit.NANOSECONDS.toMillis(t1 - t0));
        System.out.println(" * Suma " + sum);
    }

    private static int[] nowaTablica(int n) {
        int[] tab = new int[n];

        for (int i = 0; i < n; i++) {
            tab[i] = generator.nextInt();
        }

        return tab;
    }
}
