package org.jug.torun.jtwig;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/")
public class HelloController {

    @RequestMapping(value = "hello", method = RequestMethod.GET)
    public String printWelcome(ModelMap model) {

        model.addAttribute("msg", "Hello world!");

        return "hello";
    }

    @RequestMapping(value = "hello2", method = RequestMethod.GET)
    public String printWelcomeWithLogic(ModelMap model) {

        return "hello2";
    }

    @RequestMapping(value = "hello3", method = RequestMethod.GET)
    public String printWelcomeWithAsset(ModelMap model) {
        return "hello3";
    }

    @RequestMapping(value = "hello4", method = RequestMethod.GET)
    public String printWelcomeWithNewFunction(ModelMap model) {
        return "hello4";
    }

    @RequestMapping(value = "hello5", method = RequestMethod.GET)
    public String printWelcomeWithPipeTest(ModelMap model) {
        User user = new User("Jan", "Kowalski");

        model.addAttribute("user", user);

        return "hello5";
    }
}