class Utf {
	public static void main(String[] jaĸıśParametrĄŁĆ) {
		System.out.print("Hello" + " World");
	}
}
