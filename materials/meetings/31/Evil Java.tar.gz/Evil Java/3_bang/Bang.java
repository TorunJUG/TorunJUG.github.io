interface Interface<T> {}
class Bang<T> implements Interface<Interface<? super Bang<Bang<T>>>> {
	public static void main(String[] args) {
		Interface<? super Bang<Byte>> bang = new Bang<Byte>();
		System.out.println("OK");
	}
}

