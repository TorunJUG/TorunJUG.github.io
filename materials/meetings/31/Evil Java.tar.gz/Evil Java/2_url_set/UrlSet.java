import java.net.*; import java.util.*;
public class UrlSet {
	private static final String[] URL_NAMES = {
		"http://biznes.allegro.pl",  "http://marketing.allegro.pl",
		"http://smtp2.allegro.pl",   "http://smtp.allegro.pl",
	};
	public static void main(String[] args)
		throws MalformedURLException {
		Set<URL> set = new HashSet<URL>();
		for (String name : URL_NAMES)
			set.add(new URL(name));
		System.out.println(set.size());
	}
}
