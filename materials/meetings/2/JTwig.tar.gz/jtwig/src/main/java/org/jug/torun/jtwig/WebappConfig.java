package org.jug.torun.jtwig;

import com.lyncode.jtwig.mvc.JtwigViewResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
public class WebappConfig extends WebMvcConfigurerAdapter {
    @Bean
    public ViewResolver viewResolver() {
        JtwigViewResolver jtwigViewResolver = new JtwigViewResolver();
        jtwigViewResolver.setPrefix("/WEB-INF/pages/");
        jtwigViewResolver.setSuffix(".html.twig");
        jtwigViewResolver.addFunctionPackages("org.jug.torun.jtwig");
        jtwigViewResolver.setTheme("black");
        return jtwigViewResolver;
    }
}